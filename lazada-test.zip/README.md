# Lazada-test
Interview test task from Lazada, only javascript and basic html+css
